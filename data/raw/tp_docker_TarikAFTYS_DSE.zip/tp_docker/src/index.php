<?php
try {
    $pdo = new PDO("mysql:host=mysql_db;dbname=my_database;charset=utf8mb4", 'root', 'root_password');
    echo "Connexion a la base de donnees reussie !";
} catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}
?>